function [selected_features, time] = DOMBsf_d(data1, class_index, alpha, test)
    % Initialization
    [n, p] = size(data1);
    ns = max(data1);
    selected_features = [];
    selected_features1 = [];
    b = [];
    pc = [];

    
    maxK = 3;               % Maximum conditioning set size
    sepset = cell(1, p);    % Separation sets
    spouse = cell(1, p);    % Spouses of each node
    dep_sp = zeros(p, p);   % Dependency measures
    target = class_index;   % Target variable
    Data = data1;           % Data alias

    start = tic;

    
    for i = 1:p
        if i == target || sum(data1(:, i)) == 0
            continue;
        end
        
        % Feature relevance test
        [CI, dep] = my_cond_indep_chisquare(data1, i, target, [], test, alpha, ns);
      
        if CI == 0  % Feature is relevant
            selected_features = [selected_features, i];
            selected_features1 = selected_features;
            
            % Check redundancy
            for j = 1:length(selected_features)
                b = setdiff(selected_features1, selected_features(j), 'stable');
                if ~isempty(b)
                    [CI] = compter_dep_2(b, selected_features(j), target, 3, 1, alpha, test, Data);
                    if CI == 1
                        selected_features1 = b;
                    end
                end
            end
            selected_features = selected_features1;
        end
    end

    if ~isempty(selected_features)
        cpc = selected_features;
        var_index = 1:length(cpc);
        pc = [];
        
        for k = 1:length(cpc)
            current_feature = cpc(k);
            pc = [pc, current_feature];
            pc_length = length(pc);
            pc_tmp = pc;
            last_break_flag = 0;

            for j = pc_length:-1:1
                Y = pc(j);
                CanPC = mysetdiff(pc_tmp, Y);
                cutSetSize = 1;            
                other_break_flag = 0;
                
                while length(CanPC) >= cutSetSize && cutSetSize <= maxK
                    SS = subsets1(CanPC, cutSetSize);
                    for si = 1:length(SS)
                        Z = SS{si};

                        if current_feature ~= Y
                            if isempty(find(Z == current_feature, 1))
                                continue;
                            end
                        end

                        [pval] = my_g2_test(Y, target, Z, Data, ns, alpha);
                        if isnan(pval)
                            CI = 0;
                        else
                            if pval <= alpha
                                CI = 0;
                            else
                                CI = 1;
                            end
                        end

                        if CI == 1
                            pc_tmp = CanPC;
                            sepset{Y} = Z;
                            spouse{1,Y} = [];        
                            if current_feature == Y
                                last_break_flag = 1;
                            end
                            other_break_flag = 1;  
                            break;
                        end
                    end

                    if last_break_flag || other_break_flag
                        break;
                    end
                    cutSetSize = cutSetSize + 1;
                end

                if last_break_flag
                    break;
                end

                if current_feature == Y
                    % Step 2: Find spouses
                    NonTPC = mysetdiff(1:p, myunion(pc_tmp, target));
                    for kk = 1:length(NonTPC)
                        X = NonTPC(kk);
                        S = myunion(sepset{1,X}, Y);
                        [pval, dep_sp(Y,X)] = my_g2_test(target, X, S, Data, ns, alpha);
                        if isnan(pval)
                            CI = 1;
                        else
                            if pval <= alpha
                                CI = 0;
                            else
                                CI = 1;
                            end
                        end

                        if CI == 0
                            spouse{1,Y} = myunion(spouse{1,Y}, X);
                        end
                    end

                    %Remove false positives from spouses
                    SP = [];
                    [~, SP_index] = sort(dep_sp(Y, spouse{1,Y}), 'descend');
                    for f = 1:length(spouse{1,Y})
                        SP = [SP, spouse{1,Y}(SP_index(f))];
                        SP_length = length(SP);
                        SP_tmp = SP;
                        last_SP_break_flag1 = 0;
                        
                        for c = SP_length:-1:1
                            X = SP(c);
                            CanSP = mysetdiff(SP_tmp, X);
                            cutSetSize = 1;
                            SS = subsets1(CanSP, cutSetSize);
                            
                            for si = 1:length(SS)
                                Z = SS{si};
                                condset = myunion(Z, Y);

                                
                                if spouse{1,Y}(SP_index(f)) ~= X
                                    if isempty(find(Z == spouse{1,Y}(SP_index(f)), 1))
                                        continue;
                                    end
                                end

                                [pval] = my_g2_test(X, target, condset, Data, ns, alpha);
                                if isnan(pval)
                                    CI = 0;
                                else
                                    if pval <= alpha
                                        CI = 0;
                                    else
                                        CI = 1;
                                    end
                                end
                                if CI == 1
                                    SP_tmp = CanSP;
                                    if spouse{1,Y}(SP_index(f)) == X
                                        last_SP_break_flag1 = 1;
                                    end
                                    break;
                                end
                            end
                            if last_SP_break_flag1
                                break;
                            end
                        end
                        SP = SP_tmp;
                    end
                    spouse{1,Y} = SP;

                    % Further spouse refinement
                    SP = [];
                    for f = 1:length(spouse{1,Y})
                        SP = [SP, spouse{1,Y}(f)];
                        SP_length = length(SP);
                        SP_tmp = SP;
                        last_SP_break_flag2 = 0;
                        
                        for c = SP_length:-1:1
                            X = SP(c);
                            CanSP = mysetdiff(SP_tmp, X);
                            cutSetSize = 0;
                            other_SP_break_flag2 = 0;
                            
                            while length(CanSP) >= cutSetSize && cutSetSize <= maxK
                                SS = subsets1(CanSP, cutSetSize);
                                for si = 1:length(SS)
                                    Z = SS{si};
                                    condset = Z;

                                    if spouse{1,Y}(f) ~= X
                                        if isempty(find(Z == spouse{1,Y}(f), 1))
                                            continue;
                                        end
                                    end

                                    [pval] = my_g2_test(X, Y, condset, Data, ns, alpha);
                                    if isnan(pval)
                                        CI = 0;
                                    else
                                        if pval <= alpha
                                            CI = 0;
                                        else
                                            CI = 1;
                                        end
                                    end
                                    if CI == 1
                                        SP_tmp = mysetdiff(SP_tmp, X);
                                        if spouse{1,Y}(f) == X
                                            last_SP_break_flag2 = 1;
                                        end
                                        other_SP_break_flag2 = 1;
                                        break;
                                    end
                                end
                                if last_SP_break_flag2 || other_SP_break_flag2
                                    break;
                                end
                                cutSetSize = cutSetSize + 1;
                            end
                            if last_SP_break_flag2
                                break;
                            end
                        end
                        SP = SP_tmp;
                    end
                    spouse{1,Y} = SP;

                    % Final spouse refinement
                    SP = [];
                    for f = 1:length(spouse{1,Y})
                        SP = [SP, spouse{1,Y}(f)];
                        SP_length = length(SP);
                        SP_tmp = SP;
                        last_SP_break_flag3 = 0;
                        
                        for c = SP_length:-1:1
                            X = SP(c);
                            CanSP = mysetdiff(myunion(pc_tmp, SP_tmp), X);
                            cutSetSize = 1;
                            other_SP_break_flag3 = 0;
                            
                            while length(CanSP) >= cutSetSize && cutSetSize <= maxK
                                SS = subsets1(CanSP, cutSetSize);
                                for si = 1:length(SS)
                                    Z = SS{si};
                                    condset = unique([Z, Y]);

                                    if (length(intersect(pc, condset)) == 1)
                                        continue;
                                    end

                                    if spouse{1,Y}(f) ~= X
                                        if isempty(find(Z == spouse{1,Y}(f), 1))
                                            continue;
                                        end
                                    end

                                    [pval] = my_g2_test(X, target, condset, Data, ns, alpha);
                                    if isnan(pval)
                                        CI = 0;
                                    else
                                        if pval <= alpha
                                            CI = 0;
                                        else
                                            CI = 1;
                                        end
                                    end
                                    if CI == 1
                                        SP_tmp = mysetdiff(SP_tmp, X);
                                        if spouse{1,Y}(f) == X
                                            last_SP_break_flag3 = 1;
                                        end
                                        other_SP_break_flag3 = 1;
                                        break;
                                    end
                                end
                                if last_SP_break_flag3 || other_SP_break_flag3
                                    break;
                                end
                                cutSetSize = cutSetSize + 1;
                            end
                            if last_SP_break_flag3
                                break;
                            end
                        end
                        SP = SP_tmp;
                    end
                    spouse{1,Y} = SP;
                end
            end
            pc = pc_tmp;
        end
        
        % Final feature selection
        selected_features = pc;
        for y = 1:length(pc)
            selected_features = union(selected_features, spouse{1,pc(y)});
        end
    end

    time = toc(start);
end