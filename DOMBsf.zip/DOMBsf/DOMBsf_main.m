clear all
clc
close all

% Name of data
data_name='Alarm1';
data_samples=5000;

% Path of the data set
data_path=strcat('data/',data_name,'_','s',num2str(data_samples),'_','v1','.txt');
if exist(data_path,'file')==0
     fprintf('\n%s does not exist.\n\n',strcat(data_name,'_',num2str(data_samples),'.txt'));
     return;
end

% Load data
data = importdata(data_path)+1;

% Causal_Learner
alpha = input('Enter 0.01 or 0.05 of significant level = ');
target = input('Enter target T or label T = ');

test = input('Enter 1 for discrete and 0 for continues = ');
if test == 1
    test = 'g2';
    [Result1, time]=DOMBsf_d(data,target,alpha,test);
    Result3 = []; % Initialize empty for discrete case
else
    test = 'z';
    [Result2, time]=DOMBsf_z(data,target,alpha,test);
    Result3 = [];
end

% -------------------------------------
% Evaluation

% Path of the graph
graph_path=strcat('data/',data_name,'_graph.txt');
if exist(graph_path,'file')==0
     fprintf('\n%s does not exist.\n\n',strcat(data_name,'_graph.txt'));
     return;
end

% Load graph (true DAG)
graph = importdata(graph_path);

% Evaluate Markov blanket
if ~isempty(Result3)
    Result3 = cell2mat(Result3);
end
MB=union(Result1,Result3);%change the Result1 to Result2, if you execute the continouse data

[adj_F1,adj_precision,adj_recall]=evaluation_MB(MB,target,graph);
fprintf('\nThe learned Markov blanket of target %.0f is [',target);
fprintf('%d\t',MB(1:end-1));
if ~isempty(MB)
    fprintf('%d',MB(end));
end
fprintf(']\n\nadj_F1=%.2f, adj_precision=%.2f, adj_recall=%.2f\n',adj_F1,adj_precision,adj_recall);
fprintf('\nElapsed time is %.2f seconds.\n\n\n',time);