function [MB, time] = DOMBsf_z(data1, target, alpha, test)


    % Initialize variables
    [n, p] = size(data1);
    selected_features = [];
    pc = [];
    spouse = cell(1,p);
    sepset = cell(1,p);
    dep_sp = zeros(p,p);
    maxK = min(3, p-2);
    samples = n;
    Data = data1;
    
    % Conservative parameters
    forward_alpha = alpha/2;
    spouse_threshold = 0.15;
    
    start_time = tic;

    % Step 1: Find PC
    for i = 1:p
        if i == target || sum(data1(:,i)) == 0
            continue; 
        end
        
        [CI, dep] = my_cond_indep_fisher_z(data1, i, target, [], n, forward_alpha);
        if CI == 0 && ~isnan(CI) && dep > 0.1
            selected_features = [selected_features, i];
            
            
            if length(selected_features) > 1
                selected_features1 = selected_features;
                for j = length(selected_features):-1:1
                    if j > length(selected_features1), break; end
                    b = mysetdiff(selected_features1, selected_features(j));
                    if ~isempty(b)
                        [CI, ~, ~] = compter_dep_2(b, selected_features(j), target, maxK+1, 0, alpha, test, data1);
                        if CI == 1
                            selected_features1 = b;
                        end
                    end
                end
                selected_features = selected_features1;
            end
            
            % Step 2: PC Discovery with False Positive Removal
            if ~isempty(selected_features)
                cpc = selected_features;
                for k = 1:length(cpc)
                    Y = cpc(k);
                    
                    if ~ismember(Y, pc)
                        [CI, dep] = my_fisherz_test(Y, target, pc, Data, samples, forward_alpha);
                        if CI == 0 && dep > 0.1
                            pc = [pc Y];
                            
                            % PC Set Refinement
                            pc_tmp = pc;
                            for j = length(pc):-1:1
                                Yj = pc(j);
                                CanPC = mysetdiff(pc_tmp, Yj);
                                
                                for kk = 1:maxK
                                    SS = subsets1(CanPC, min(kk,length(CanPC)));
                                    for si = 1:min(length(SS), 100)
                                        Z = SS{si};
                                        [CI] = my_fisherz_test(Yj, target, Z, Data, samples, alpha);
                                        if CI == 1
                                            pc_tmp = CanPC;
                                            if Yj <= p
                                                sepset{Yj} = Z;
                                                spouse{Yj} = [];
                                            end
                                            break;
                                        end
                                    end
                                    if ~ismember(Yj, pc_tmp), break; end
                                end
                            end
                            pc = pc_tmp;
                        end
                    end
                    
                    % Spouse Identification with False Positive Removal
                    if ismember(Y, pc) && Y <= p
                        NonTPC = mysetdiff(1:p, myunion(pc, target));
                        for kk = 1:length(NonTPC)
                            X = NonTPC(kk);
                            if X <= p
                                if ~isempty(sepset) && length(sepset) >= X && ~isempty(sepset{X}) && iscell(sepset)
                                    S = myunion(sepset{X}, Y);
                                else
                                    S = Y;
                                end
                                
                                [CI, dep] = my_fisherz_test(target, X, S, Data, samples, forward_alpha);
                                if Y <= p && X <= p
                                    dep_sp(Y,X) = dep;
                                end
                                
                                if CI == 0 && dep > spouse_threshold && Y <= p
                                    if isempty(spouse{Y})
                                        spouse{Y} = X;
                                    else
                                        spouse{Y} = myunion(spouse{Y}, X);
                                    end
                                end
                            end
                        end
                        
                        
                        if Y <= p && ~isempty(spouse) && length(spouse) >= Y && ~isempty(spouse{Y}) && iscell(spouse)
                            SP = spouse{Y};
                            
                            % Sort by dependency strength
                            valid_indices = SP(SP<=p & SP>0);
                            [~, idx] = sort(dep_sp(Y,valid_indices), 'descend');
                            SP = valid_indices(idx);
                            
                            % Remove conditionally independent spouses
                            f = 1;
                            while f <= length(SP)
                                X = SP(f);
                                if X > p, SP(f) = []; continue; end
                                
                                CanSP = mysetdiff(SP, X);
                                for kk = 0:min(maxK, length(CanSP))
                                    SS = subsets1(CanSP, kk);
                                    for si = 1:min(length(SS), 20)
                                        Z = SS{si};
                                        condset = myunion(Z, Y);
                                        [CI] = my_fisherz_test(X, target, condset, Data, samples, alpha);
                                        if CI == 1
                                            SP = mysetdiff(SP, X);
                                            f = f - 1;
                                            break;
                                        end
                                    end
                                    if ~ismember(X, SP), break; end
                                end
                                f = f + 1;
                            end
                            
                            % Final dependency threshold
                            valid_spouses = [];
                            for j = 1:length(SP)
                                if SP(j) <= p && dep_sp(Y,SP(j)) > spouse_threshold
                                    valid_spouses = [valid_spouses SP(j)];
                                end
                            end
                            spouse{Y} = valid_spouses;
                        end
                        
                        % STEP 3: Remove false positives from PC set
                        M = pc;
                        for long = length(M):-1:1
                            Yj = M(long);
                            CanPC = mysetdiff(M, Yj);
                            
                            for kk = 1:min(maxK, length(CanPC))
                                SS = subsets1(CanPC, kk);
                                for si = 1:min(length(SS), 20)
                                    Z = SS{si};
                                    % Safe cell array access
                                    if ~isempty(spouse) && all(Z <= p) && all(Z > 0) && ...
                                       length(spouse) >= Z(1) && ~isempty(spouse{Z(1)}) && iscell(spouse)
                                        TestSet = myunion(Z, spouse{Z(1)});
                                    else
                                        TestSet = Z;
                                    end
                                    [CI] = my_fisherz_test(Yj, target, TestSet, Data, samples, alpha);
                                    if CI == 1
                                        M = mysetdiff(M, Yj);
                                        if Yj <= p
                                            spouse{Yj} = [];
                                        end
                                        break;
                                    end
                                end
                                if ~ismember(Yj, M), break; end
                            end
                        end
                        pc = M;
                    end
                end
            end
        end
    end


    MB = pc;
    for i = 1:min(length(spouse), p)
        if ~isempty(spouse) && length(spouse) >= i && ~isempty(spouse{i}) && iscell(spouse)
            MB = myunion(MB, spouse{i});
        end
    end

    time = toc(start_time);
end


function [CI, dep, p_value] = my_cond_indep_fisher_z(data, x, y, S, N, alpha)
    if isempty(S)
        [r, p_value] = corr(data(:,x), data(:,y));
    else
        [r, p_value] = partialcorr(data(:,x), data(:,y), data(:,S));
    end
    z = 0.5*log((1+r)/(1-r));
    z0 = 0;
    SE = 1/sqrt(N-length(S)-3);
    T = (z-z0)/SE;
    th = norminv(1-alpha/2);
    CI = (abs(T) < th);
    dep = abs(T);
end

function [CI, dep] = my_fisherz_test(X, Y, Z, Data, samples, alpha)
    [CI, dep] = my_cond_indep_fisher_z(Data, X, Y, Z, samples, alpha);
end

function [CI, S, dep1, p_value] = compter_dep_2(bcf, var, target, max_k, discrete, alpha, test, data)
    S = [];
    dep1 = 0;
    n_bcf = length(bcf);
    N = size(data,1);
    max_cond_size = min(max_k, n_bcf);
    CI = 0;
    p_value = 1;

    for cond_size = 1:max_cond_size
        if n_bcf >= cond_size
            cond_index = combnk(1:n_bcf, cond_size);
            for idx = 1:min(size(cond_index,1), 100)
                cond = bcf(cond_index(idx,:));
                [CI, dep, p_value] = my_cond_indep_fisher_z(data, var, target, cond, N, alpha);
                S = cond;
                dep1 = dep;
                if CI == 1 || isnan(dep)
                    return;
                end
            end
        end
    end
end

function SS = subsets1(S, k)
    if isempty(S) || k < 0 || k > length(S)
        SS = {};
    elseif k == 0
        SS = {[]};
    else
        indices = combnk(1:length(S), k);
        SS = cell(size(indices,1),1);
        for i = 1:size(indices,1)
            SS{i} = S(indices(i,:));
        end
    end
end

function C = mysetdiff(A,B)
    if isempty(A)
        C = [];
    elseif isempty(B)
        C = A;
    else
        max_val = max([max(A), max(B)]);
        if ~isempty(max_val) && max_val > 0
            bits = zeros(1, max_val);
            bits(A) = 1;
            bits(B) = 0;
            C = find(bits);
        else
            C = [];
        end
    end
end

function C = myunion(A,B)
    if isempty(A)
        C = B;
    elseif isempty(B)
        C = A;
    else
        max_val = max([max(A), max(B)]);
        if ~isempty(max_val) && max_val > 0
            bits = zeros(1, max_val);
            bits(A) = 1;
            bits(B) = 1;
            C = find(bits);
        else
            C = [];
        end
    end
end