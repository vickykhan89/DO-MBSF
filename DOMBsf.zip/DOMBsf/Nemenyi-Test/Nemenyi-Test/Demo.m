%% drawNemenyi demo
% Farshid Sepehrband - Jeiran Choupan
% nemenyi.m function is borrowed from: http://kourentzes.com/forecasting/2013/04/19/nemenyi-test/

% Let's say we have a matrix of MxN, as the input:
% M measurements x N techniques

% First we define a cell of strings, including names of techniques. 
% for example: 
% Names = {'tech #1','tech #2',...,'tech #n'};

% Then, we define our output folder and output name and run the code.

% Here is an example, assuming you are comparing 4 techniques:
% results = [0.88	0.64 0.89 0.92 0.9 0.84; 
%            0.44	0.00 0.45 0.00 0.80 0.98; 
%            0.92	0.45 0.76 0.94 0.66	0.98; 
%            0.94	0.85 0.94 0.63 0.94	0.94;
%            0.90 0.40 0.85 0.91 0.74	0.83;
%            0.93	0.92 0.88 0.70 0.89	0.94;
%            0.89	0.17 0.82 0.88 0.81	0.92;
%            0.44	0.00 0.59 0.00 0.53	0.64;
%            0.79	0.16 0.64 0.76 0.95	0.99;
%            0.40 0.00 0.29 0.00 0.41	0.36]; 

%%% for 1000 offline algorithms
results = [0.271, 0.383, 0.282, 0.285, 0.43, 0.065;
           0.665, 0.000, 0.642, 0.000, 0.263, 0.055;
           0.271, 0.383, 0.282	0.42, 0.278, 0.065;
           0.152, 0.251, 0.158	0.33, 0.15, 0.03;
           0.228, 0.516, 0.281	0.233, 0.334, 0.075;
           0.402, 0.511, 0.29,	0.491, 0.435, 0.045;
           0.086, 0.829, 0.30,	0.11, 0.267, 0.025;
           0.665, 0.000, 0.660	0.000, 0.644, 0.15;
           0.146, 0.762, 0.29,	0.152, 0.19, 0.12;
           0.000, 0.000, 0.722,	0.000, 0.731, 0.06];
       
       
% %%% for 5000 offline algorithms
% results = [0.180, 0.520, 0.232, 0.156, 0.283, 0.169;
%     0.612, 1.000, 0.585, 1.000, 0.188, 0.064;
%     0.045, 0.266, 0.135, 0.036, 0.342, 0.068;
%     0.110, 0.244, 0.134, 0.322, 0.052, 0.055;
%     0.171, 0.369, 0.232, 0.174, 0.266, 0.297;
%     0.144, 0.078, 0.245, 0.171, 0.092, 0.046;
%     0.125, 0.552, 0.198, 0.141, 0.303, 0.066;
%     0.612, 1.000, 0.359, 1.000, 0.522, 0.571;
%     0.160, 0.546, 0.226, 0.259, 0.084, 0.028;
%     0.773, 1.000, 0.716, 1.000, 0.623, 0.654];


%%% for 1000 online algorithms
% results = [0.034, 0.052, 0.041, 0.015;
%            0.028, 0.065, 0.023,	0.011;
%            0.021, 0.078, 0.056, 0.012;
%            0.016, 0.032, 0.015, 0.014;
%            0.043, 0.01,  0.052, 0.017;
%            0.062, 0.081, 0.05,	0.011;
%            0.019, 0.008, 0.035,	0.001;
%            0.077, 0.066, 0.046, 0.038;
%            0.008, 0.009, 0.022,	0.005;
%            0.095, 0.053, 0.076,	0.049];


%%% for 5000 online algorithms
% results = [0.545, 0.623, 0.237, 0.381;
%            0.082, 0.185, 0.191, 0.019;
%            0.079, 0.057, 0.423, 0.005;
%            0.123, 0.157, 0.068, 0.012;
%            0.184, 0.192, 0.457,	0.168;
%            0.323, 0.257, 0.184,	0.089;
%            0.182, 0.095, 0.123,	0.001;
%            0.457, 0.489, 0.285,	0.281;
%            0.057, 0.092, 0.123,	0.005;
%            0.785, 0.457, 0.679,	0.223];% Example F1-scores across 5 datasets;
Names = {'HITON-MB','STMB','BAMB','EMB','EAMB','DO-MB_{SF}'}; % names
% Names = {'OCFSSF','MB-SF','OL_{aMB}','DO-MB_{SF}'}; % names
OutputFolder  = 'D:\WaqarPhD\PhDYsu\MB_FeatureSelection_Work_submition_Code\SixtyPaper\Submission_Journals\Information Sciences\Statistical test';                       % Output folder
Outname = 'NemenyiResults';                        % Output name
drawNemenyi(results, Names, OutputFolder, Outname);

% Now you should see a "NemeyiResults.tif" on yoru Desktop folder.
% You can change the print options (see %%print section of drawNemenyi.m)
% Enjoy!
