function drawNemenyi(Results,Names,OutFolder,OutName)

figure(1)
cd = fsCD(Results);
Ne = size(Results,2);
for i = 1:size(Results,1)
    Ran(i,:) = tiedrank(Results(i,:));
end
plot([1 Ne],[0 0],'k')
hold on
plot(1:Ne,zeros(1,Ne),'k+')
xlim([-1 Ne+2])
plot(mean(Ran),zeros(1,Ne),'k.')
if Ne > 8
    ylim([-0.4 0.3])
else
    ylim([-0.3 0.3])
end
[RanSort,RanIndx] = sort(mean(Ran),'ascend');
divInd = round(length(RanSort)/2);
LinSpa = 0.05;

for i = 1:divInd
    
    plot([RanSort(i) RanSort(i)],[-0.01 -0.01-(i*LinSpa)],'k')
    plot([1 RanSort(i)],[-0.01-(i*LinSpa) -0.01-(i*LinSpa)],'k')
    text(0.9,-0.01-(i*LinSpa),char(Names(RanIndx(i))),'HorizontalAlignment','right', 'FontName', 'Times New Roman')
end

i = 1;
for c = length(RanSort):-1:divInd+1
    
    plot([RanSort(c) RanSort(c)],[-0.01 -0.01-(i*LinSpa)],'k')
    plot([RanSort(c) Ne],[-0.01-(i*LinSpa) -0.01-(i*LinSpa)],'k')
    text(Ne+.1,-0.01-(i*LinSpa),char(Names(RanIndx(c))), 'FontName', 'Times New Roman')
    i = i+1;
end
for i = 1:length(RanSort)
    text(i-0.08,0.035,num2str(i),'FontSize',7,'VerticalAlignment','top', 'FontWeight', 'bold')
end

h=plot([1 1],[0.048 0.052]);
plot([1+cd 1+cd],[0.048 0.052],'Color',[0, 0, 0], 'LineWidth', 2);
plot([1 1+cd],[0.05 0.05],'Color',[0, 0, 0], 'LineWidth', 2);
text(1, 0.05+0.02, 'CD','Color',[0, 0, 0], 'FontName', 'Times New Roman', 'FontWeight', 'bold')

%% Draw significant lines
Temp = Results(:,RanIndx);
[p, Nemenyi, meanrank, CDa, rankmean] = nemenyi(Temp, 1);
if p<0.05
    NEM = tril(Nemenyi==1);
    Ind = zeros(1,size(NEM,2));
    for i = 1:size(NEM,2)
        [aa,bb] = find(NEM(:,i)==0);
        if numel(aa)~=0;Ind(i) = aa(end);end
    end
    
    [C,ia,ic] = unique(Ind);
    count = 1;
    for i = ia' %size(unique(Ind),1)
        if Ne > 1 % change this to 4 later
            if mod(count,2)==0
                plot([RanSort(i) RanSort(C(count))],...
                    [-0.01-(2*LinSpa*0.4) -0.01-(2*LinSpa*0.4)]);
            else
                plot([RanSort(i) RanSort(C(count))],...
                    [-0.01-(LinSpa*0.4) -0.01-(LinSpa*0.4)], 'Color', [0, 0, 0], 'LineWidth', 2);
            end
%             count=count+1;
        else
            error('Matrix size is can not be Nx1')
        end
        
    end
end
title(['Friedman p = ' num2str(p)])

%% print
box off
axis off
set(gca,'LineWidth',0.75,'FontSize',8,'FontName','Arial');
set(gcf, 'PaperUnits', 'centimeters');
set(gcf, 'PaperPosition', [0 0 12 8]);
print('-dpng' ,'-r600',[OutFolder '/' OutName '.png'])
% close(1)